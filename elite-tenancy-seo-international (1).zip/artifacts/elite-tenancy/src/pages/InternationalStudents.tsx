import { Link } from "wouter";
import { motion } from "framer-motion";
import { GraduationCap, Shield, Clock, Globe, Star, CheckCircle2, ArrowRight, MapPin } from "lucide-react";
import { Button } from "@/components/ui/button";
import PublicLayout from "@/components/PublicLayout";
import { useSeo } from "@/hooks/use-seo";

const universities = [
  { city: "London", unis: ["UCL", "King's College", "Imperial", "LSE", "SOAS", "City"], avg: "£1,200–£2,400/mo", slug: "london" },
  { city: "Manchester", unis: ["Univ. of Manchester", "Manchester Met", "Salford"], avg: "£650–£1,100/mo", slug: "manchester" },
  { city: "Birmingham", unis: ["Univ. of Birmingham", "Aston", "BCU"], avg: "£600–£950/mo", slug: "birmingham" },
  { city: "Edinburgh", unis: ["Univ. of Edinburgh", "Heriot-Watt", "Napier"], avg: "£700–£1,200/mo", slug: "edinburgh" },
  { city: "Leeds", unis: ["Univ. of Leeds", "Leeds Beckett"], avg: "£600–£900/mo", slug: "leeds" },
  { city: "Bristol", unis: ["Univ. of Bristol", "UWE Bristol"], avg: "£700–£1,100/mo", slug: "bristol" },
];

const countries = [
  { flag: "🇮🇳", name: "India", students: "150,000+", note: "Largest international student group in the UK" },
  { flag: "🇨🇳", name: "China", students: "120,000+", note: "Second largest international student group" },
  { flag: "🇳🇬", name: "Nigeria", students: "55,000+", note: "Fastest-growing international student group" },
  { flag: "🇺🇸", name: "United States", students: "20,000+", note: "Juniors & exchange students" },
  { flag: "🇵🇰", name: "Pakistan", students: "33,000+", note: "Strong university presence across the UK" },
  { flag: "🇦🇪", name: "UAE", students: "8,000+", note: "Premium property seekers" },
  { flag: "🇸🇬", name: "Singapore", students: "7,000+", note: "Graduate and postgraduate focus" },
  { flag: "🇦🇺", name: "Australia", students: "6,000+", note: "Exchange & postgraduate students" },
];

const steps = [
  { step: "01", title: "Search From Abroad", desc: "Browse verified UK properties before you arrive. No viewing required — our verified listings include video tours." },
  { step: "02", title: "Create Your Renter Passport", desc: "Build your verified profile with your university acceptance letter, guarantor details, and identity documents." },
  { step: "03", title: "Right to Rent Guidance", desc: "We walk you through the UK's Right to Rent requirements for international students — student visas are accepted." },
  { step: "04", title: "Move In Confident", desc: "Deposit protected, tenancy agreement checked, inventory completed. You arrive to a property ready for you." },
];

const faqs = [
  { q: "Can international students rent privately in the UK?", a: "Yes. International students with a valid Tier 4 / Student visa can rent private accommodation in the UK. Landlords must conduct a Right to Rent check, which your student visa and BRP card will satisfy. Elite Tenancy guides you through every step of the Right to Rent process." },
  { q: "Do international students need a UK guarantor?", a: "Many UK landlords require a guarantor for students, particularly international students. A guarantor must typically be a UK resident earning at least 30x the monthly rent annually. If you don't have a UK guarantor, we can recommend third-party guarantor services such as Housing Hand or Dlighted, which are widely accepted." },
  { q: "How much is rent for international students in London?", a: "Average room rents in London range from £900–£2,000/month depending on location. Zone 1–2 (central London, near most universities) tends to command £1,200–£2,000. Outer zones (3–6) offer better value at £800–£1,200/month. Always budget for an upfront holding deposit (1 week's rent) and security deposit (5 weeks' rent maximum under the Tenant Fees Act)." },
  { q: "Can I rent a UK property before arriving in the UK?", a: "Yes. Elite Tenancy's verified listings include video tours, floor plans, and detailed descriptions. You can reserve a property from abroad by paying a holding deposit. We recommend arriving at least 2 weeks before your course starts to complete referencing and sign your tenancy agreement." },
  { q: "What documents do international students need to rent in the UK?", a: "Typically: valid passport, valid UK student visa or BRP card, university offer or acceptance letter, proof of maintenance funds (bank statement), and a guarantor or evidence of upfront rent payment (some landlords accept 3–6 months upfront). Elite Tenancy will tell you exactly what each specific landlord requires." },
  { q: "Is a Tier 4 / Student visa accepted for Right to Rent?", a: "Yes. A valid Student visa (formerly Tier 4) combined with your Biometric Residence Permit (BRP) satisfies the UK Right to Rent check. Time-limited visas must be re-checked at the shorter of: the visa expiry date or 12 months. Elite Tenancy handles this for you automatically." },
];

export default function InternationalStudents() {
  useSeo({
    title: "UK Student Accommodation for International Students 2026 | Elite Tenancy",
    description: "Find verified private rental accommodation near UK universities. Guidance for international students from India, Nigeria, USA, UAE, Singapore and 50+ countries. Right to Rent help, guarantor advice, remote viewing.",
    canonical: "https://www.elitetenancy.co.uk/international-students",
  });

  return (
    <PublicLayout>
      {/* Hero */}
      <section className="relative bg-gradient-to-br from-slate-900 via-blue-950 to-slate-900 text-white py-24 px-4">
        <div className="max-w-5xl mx-auto text-center">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
            <div className="inline-flex items-center gap-2 bg-blue-500/20 text-blue-300 px-4 py-2 rounded-full text-sm font-medium mb-6">
              <Globe className="w-4 h-4" />
              Serving students from 50+ countries
            </div>
            <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
              UK Student Accommodation<br />
              <span className="text-blue-400">for International Students</span>
            </h1>
            <p className="text-xl text-slate-300 max-w-3xl mx-auto mb-10">
              Find verified private rental accommodation near any UK university — before you arrive.
              We guide you through Right to Rent, guarantor requirements, and every step of the UK letting process.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/listings">
                <Button size="lg" className="bg-blue-500 hover:bg-blue-400 text-white px-8 py-6 text-lg">
                  Browse UK Properties <ArrowRight className="ml-2 w-5 h-5" />
                </Button>
              </Link>
              <Link href="/renter-passport">
                <Button size="lg" variant="outline" className="border-white/30 text-white hover:bg-white/10 px-8 py-6 text-lg">
                  Create Renter Passport
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* International students by country */}
      <section className="py-16 px-4 bg-slate-50">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-center text-slate-900 mb-4">We Help Students From Across the World</h2>
          <p className="text-center text-slate-500 mb-12 max-w-2xl mx-auto">Over 600,000 international students study in the UK every year. We've helped students from every major sending country find a home.</p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {countries.map((c) => (
              <div key={c.name} className="bg-white rounded-xl p-5 shadow-sm border border-slate-100 text-center">
                <div className="text-4xl mb-3">{c.flag}</div>
                <div className="font-semibold text-slate-900">{c.name}</div>
                <div className="text-blue-600 text-sm font-medium">{c.students}</div>
                <div className="text-slate-500 text-xs mt-1">{c.note}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How it works */}
      <section className="py-16 px-4">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-3xl font-bold text-center text-slate-900 mb-4">How to Rent in the UK as an International Student</h2>
          <p className="text-center text-slate-500 mb-12 max-w-2xl mx-auto">We've simplified the UK letting process for international students — from searching abroad to moving in.</p>
          <div className="grid md:grid-cols-2 gap-8">
            {steps.map((s) => (
              <div key={s.step} className="flex gap-5">
                <div className="flex-shrink-0 w-12 h-12 bg-blue-600 text-white rounded-xl flex items-center justify-center font-bold text-lg">{s.step}</div>
                <div>
                  <h3 className="font-semibold text-slate-900 text-lg mb-1">{s.title}</h3>
                  <p className="text-slate-600">{s.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Cities */}
      <section className="py-16 px-4 bg-slate-50">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-center text-slate-900 mb-4">Student Rentals by University City</h2>
          <p className="text-center text-slate-500 mb-12 max-w-2xl mx-auto">Find properties near your university. All listings are verified and available to international students.</p>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {universities.map((u) => (
              <Link key={u.city} href={`/${u.slug}`}>
                <div className="bg-white rounded-xl p-6 shadow-sm border border-slate-100 hover:border-blue-300 hover:shadow-md transition-all cursor-pointer">
                  <div className="flex items-center gap-2 mb-3">
                    <MapPin className="w-4 h-4 text-blue-600" />
                    <h3 className="font-bold text-slate-900 text-lg">{u.city}</h3>
                  </div>
                  <p className="text-slate-500 text-sm mb-3">{u.unis.join(" · ")}</p>
                  <div className="text-blue-600 font-semibold text-sm">Avg: {u.avg}</div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Key protections */}
      <section className="py-16 px-4">
        <div className="max-w-5xl mx-auto">
          <h2 className="text-3xl font-bold text-center text-slate-900 mb-12">Your Rights as an International Tenant in the UK</h2>
          <div className="grid md:grid-cols-3 gap-6">
            {[
              { icon: Shield, title: "Deposit Protection", desc: "Your deposit must be held in a government-backed Tenancy Deposit Scheme (TDS, DPS, or mydeposits). Elite Tenancy verifies this for every property." },
              { icon: CheckCircle2, title: "Tenant Fees Act 2019", desc: "Landlords and agents cannot charge tenants for referencing, admin, or inventory. The only permitted fees are rent, a deposit (max 5 weeks), and a holding deposit (max 1 week)." },
              { icon: Star, title: "Renters Rights Act 2026", desc: "As of May 2026, Section 21 no-fault evictions are abolished. Your landlord cannot evict you without a valid legal ground. Rental bidding wars are also now illegal." },
            ].map((item) => (
              <div key={item.title} className="bg-slate-50 rounded-xl p-6 border border-slate-100">
                <item.icon className="w-8 h-8 text-blue-600 mb-4" />
                <h3 className="font-semibold text-slate-900 text-lg mb-2">{item.title}</h3>
                <p className="text-slate-600 text-sm">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-16 px-4 bg-slate-50">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold text-center text-slate-900 mb-12">Frequently Asked Questions</h2>
          <div className="space-y-6">
            {faqs.map((faq) => (
              <div key={faq.q} className="bg-white rounded-xl p-6 shadow-sm border border-slate-100">
                <h3 className="font-semibold text-slate-900 text-lg mb-3">{faq.q}</h3>
                <p className="text-slate-600 leading-relaxed">{faq.a}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 px-4 bg-blue-600 text-white text-center">
        <div className="max-w-2xl mx-auto">
          <GraduationCap className="w-12 h-12 mx-auto mb-4 opacity-80" />
          <h2 className="text-3xl font-bold mb-4">Ready to Find Your UK Student Home?</h2>
          <p className="text-blue-100 mb-8">Browse verified properties near your university and get expert guidance throughout the letting process — free for tenants.</p>
          <Link href="/listings">
            <Button size="lg" className="bg-white text-blue-600 hover:bg-blue-50 px-10 py-6 text-lg font-semibold">
              Search UK Properties <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
          </Link>
        </div>
      </section>
    </PublicLayout>
  );
}
