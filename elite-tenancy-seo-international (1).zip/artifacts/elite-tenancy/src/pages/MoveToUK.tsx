import { Link } from "wouter";
import { motion } from "framer-motion";
import { Plane, Globe, Shield, Home, CheckCircle2, Briefcase, ArrowRight, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import PublicLayout from "@/components/PublicLayout";
import { useSeo } from "@/hooks/use-seo";

const profiles = [
  { icon: Briefcase, title: "Skilled Workers & Graduates", desc: "Moving to the UK on a Skilled Worker or Graduate visa? We have properties ready for January or September movers near all major business districts.", link: "/listings" },
  { icon: Globe, title: "Returning Expats", desc: "Coming back to the UK after years abroad? Credit history gaps are common — we work with landlords who understand expat circumstances.", link: "/listings" },
  { icon: Star, title: "Premium Relocations", desc: "Executive or senior-level move? We handle end-to-end relocation sourcing across London, Edinburgh, Manchester and beyond.", link: "/contact" },
  { icon: Home, title: "Family Relocations", desc: "Moving with a family? We specialise in finding houses with outdoor space, near good schools, with quick access to transport links.", link: "/listings" },
];

const destinations = [
  { city: "London", why: "Global finance, tech, creative, and government roles", avg: "£2,850/mo", slug: "london" },
  { city: "Manchester", why: "Northern Powerhouse — media, tech, and finance hub", avg: "£1,200/mo", slug: "manchester" },
  { city: "Edinburgh", why: "Finance, tech, and international law", avg: "£1,400/mo", slug: "edinburgh" },
  { city: "Birmingham", why: "HSBC HQ, KPMG, Deloitte, and growing tech sector", avg: "£1,000/mo", slug: "birmingham" },
  { city: "Bristol", why: "Aerospace, tech, and creative industries", avg: "£1,300/mo", slug: "bristol" },
  { city: "Leeds", why: "Legal, financial, and healthcare sectors", avg: "£950/mo", slug: "leeds" },
];

const faqs = [
  { q: "Can I rent a UK property from overseas before I arrive?", a: "Yes. Elite Tenancy's video-verified listings allow you to select and reserve a property remotely. You'll pay a holding deposit (max 1 week's rent) to secure it, then complete referencing and sign your tenancy agreement once you arrive or via video call." },
  { q: "Do I need a UK bank account to rent in the UK?", a: "Most landlords require rent to be paid by UK bank transfer (standing order). You can set up a UK bank account before arriving using digital banks like Monzo, Starling, or Wise — all accept overseas applications. We work with landlords who are flexible on this during the first month." },
  { q: "How much deposit will I need to rent in the UK?", a: "Under the Tenant Fees Act 2019, security deposits are capped at 5 weeks' rent (or 6 weeks for rents over £50,000/year). You'll also pay a holding deposit of up to 1 week's rent to secure a property while your references are checked. Your deposit must be protected in a government-approved Tenancy Deposit Scheme." },
  { q: "How long does the UK rental process take?", a: "From offer accepted to moving in typically takes 2–4 weeks, allowing time for referencing, right to rent checks, and tenancy agreement signing. With Elite Tenancy's pre-qualified tenant process, we can often complete in 7–10 days for applicants with all documents ready." },
  { q: "Do I need a guarantor if I'm moving to the UK from abroad?", a: "Some landlords require a UK-based guarantor, particularly for newly arrived international tenants. If you don't have a UK guarantor, we work with landlords who accept: 3–6 months' rent upfront, third-party guarantor services (Housing Hand, Dlighted), or a rent-in-advance arrangement. Your exact options depend on your circumstances." },
  { q: "What is the Right to Rent check and how does it affect me?", a: "All UK landlords must verify your legal right to rent before the tenancy starts. For most migrants, this means checking your passport and visa. EU/EEA nationals check their Settled or Pre-Settled Status via the UK Home Office online service. Skilled Worker, Graduate, and other visa holders use their visa and BRP. Elite Tenancy handles the entire Right to Rent process for you." },
];

const timeline = [
  { phase: "8–12 weeks before", title: "Start Your Search", desc: "Browse listings, create your Renter Passport, and shortlist properties. The UK market moves fast — especially London." },
  { phase: "4–6 weeks before", title: "Apply & Reference", desc: "Submit applications. Prepare: passport, visa/right to rent docs, employment contract/letter, 3 months' payslips or bank statements." },
  { phase: "2–4 weeks before", title: "Sign & Deposit", desc: "Sign your tenancy agreement digitally. Pay your deposit (protected by law in a government scheme) and first month's rent." },
  { phase: "Move-in day", title: "Check-In Inventory", desc: "Complete a detailed check-in inventory with photos. This protects you at the end of the tenancy when your deposit is returned." },
];

export default function MoveToUK() {
  useSeo({
    title: "Moving to the UK? Find Rental Property Before You Arrive | Elite Tenancy",
    description: "Relocating to the UK from the USA, UAE, India, Australia, Canada or anywhere in the world? Find verified UK rental properties remotely, get Right to Rent guidance, and move in with confidence. Free for tenants.",
    canonical: "https://www.elitetenancy.co.uk/move-to-uk",
  });

  return (
    <PublicLayout>
      {/* Hero */}
      <section className="relative bg-gradient-to-br from-slate-900 via-slate-800 to-blue-950 text-white py-24 px-4">
        <div className="max-w-5xl mx-auto text-center">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
            <div className="inline-flex items-center gap-2 bg-emerald-500/20 text-emerald-300 px-4 py-2 rounded-full text-sm font-medium mb-6">
              <Plane className="w-4 h-4" />
              Helping people from 50+ countries move to the UK
            </div>
            <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
              Moving to the UK?<br />
              <span className="text-emerald-400">Find Your Home Before You Arrive.</span>
            </h1>
            <p className="text-xl text-slate-300 max-w-3xl mx-auto mb-10">
              Elite Tenancy helps skilled workers, graduates, expats, and families relocating to the UK
              find verified rental properties — from anywhere in the world — with expert guidance on
              Right to Rent, guarantors, and UK letting law.
            </p>
            <div className="flex flex-wrap gap-3 justify-center mb-10">
              {["🇺🇸 USA", "🇦🇪 UAE", "🇮🇳 India", "🇦🇺 Australia", "🇨🇦 Canada", "🇸🇬 Singapore", "🇳🇬 Nigeria", "🇩🇪 Germany", "🇫🇷 France", "🇵🇰 Pakistan"].map(c => (
                <span key={c} className="bg-white/10 px-3 py-1 rounded-full text-sm">{c}</span>
              ))}
            </div>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/listings">
                <Button size="lg" className="bg-emerald-500 hover:bg-emerald-400 text-white px-8 py-6 text-lg">
                  Browse UK Rentals <ArrowRight className="ml-2 w-5 h-5" />
                </Button>
              </Link>
              <Link href="/renter-passport">
                <Button size="lg" variant="outline" className="border-white/30 text-white hover:bg-white/10 px-8 py-6 text-lg">
                  Create Renter Passport
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Who we help */}
      <section className="py-16 px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-center text-slate-900 mb-4">Who We Help</h2>
          <p className="text-center text-slate-500 mb-12 max-w-2xl mx-auto">Whether you're on a Skilled Worker visa, returning after years abroad, or moving your family to the UK, we have landlords and properties suited to your situation.</p>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {profiles.map((p) => (
              <Link key={p.title} href={p.link}>
                <div className="bg-white rounded-xl p-6 shadow-sm border border-slate-100 hover:border-emerald-300 hover:shadow-md transition-all cursor-pointer h-full">
                  <p.icon className="w-8 h-8 text-emerald-600 mb-4" />
                  <h3 className="font-semibold text-slate-900 text-lg mb-2">{p.title}</h3>
                  <p className="text-slate-600 text-sm">{p.desc}</p>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Timeline */}
      <section className="py-16 px-4 bg-slate-50">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold text-center text-slate-900 mb-4">Your UK Relocation Timeline</h2>
          <p className="text-center text-slate-500 mb-12 max-w-2xl mx-auto">The UK rental market moves quickly. Here's when to do what.</p>
          <div className="space-y-6">
            {timeline.map((t, i) => (
              <div key={t.phase} className="flex gap-6 items-start">
                <div className="flex-shrink-0 text-right w-32">
                  <span className="text-emerald-600 font-semibold text-sm">{t.phase}</span>
                </div>
                <div className="flex-shrink-0 w-4 h-4 rounded-full bg-emerald-500 mt-1 relative">
                  {i < timeline.length - 1 && <div className="absolute left-1.5 top-4 w-0.5 h-20 bg-emerald-200" />}
                </div>
                <div className="pb-8">
                  <h3 className="font-semibold text-slate-900 text-lg mb-1">{t.title}</h3>
                  <p className="text-slate-600">{t.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Destination cities */}
      <section className="py-16 px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-center text-slate-900 mb-4">Top UK Cities for International Movers</h2>
          <p className="text-center text-slate-500 mb-12 max-w-2xl mx-auto">Choose the city that matches your employer's location or your lifestyle priorities.</p>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {destinations.map((d) => (
              <Link key={d.city} href={`/${d.slug}`}>
                <div className="bg-white rounded-xl p-6 shadow-sm border border-slate-100 hover:border-emerald-300 hover:shadow-md transition-all cursor-pointer">
                  <h3 className="font-bold text-slate-900 text-xl mb-2">{d.city}</h3>
                  <p className="text-slate-500 text-sm mb-3">{d.why}</p>
                  <div className="text-emerald-600 font-semibold">Avg rent: {d.avg}</div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Protections */}
      <section className="py-16 px-4 bg-emerald-50">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold text-center text-slate-900 mb-12">Your Legal Protections as a UK Renter</h2>
          <div className="grid md:grid-cols-3 gap-6">
            {[
              { icon: Shield, title: "Deposit Protection", desc: "All security deposits must be held in a government-backed scheme. You get it back at the end of your tenancy if the property is returned in good condition." },
              { icon: CheckCircle2, title: "No Illegal Fees", desc: "Landlords and agents cannot charge for referencing, admin, or credit checks. Only rent, security deposit (max 5 weeks), and holding deposit (max 1 week) are permitted." },
              { icon: Home, title: "Secure Tenancies", desc: "Since May 2026, all tenancies are periodic (rolling). Your landlord cannot evict you without a valid legal reason — no-fault Section 21 evictions are now illegal." },
            ].map((item) => (
              <div key={item.title} className="bg-white rounded-xl p-6 shadow-sm border border-emerald-100">
                <item.icon className="w-8 h-8 text-emerald-600 mb-4" />
                <h3 className="font-semibold text-slate-900 text-lg mb-2">{item.title}</h3>
                <p className="text-slate-600 text-sm">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-16 px-4">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold text-center text-slate-900 mb-12">Frequently Asked Questions</h2>
          <div className="space-y-6">
            {faqs.map((faq) => (
              <div key={faq.q} className="bg-slate-50 rounded-xl p-6 border border-slate-100">
                <h3 className="font-semibold text-slate-900 text-lg mb-3">{faq.q}</h3>
                <p className="text-slate-600 leading-relaxed">{faq.a}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 px-4 bg-slate-900 text-white text-center">
        <div className="max-w-2xl mx-auto">
          <Plane className="w-12 h-12 mx-auto mb-4 opacity-80 text-emerald-400" />
          <h2 className="text-3xl font-bold mb-4">Start Your UK Rental Search Today</h2>
          <p className="text-slate-400 mb-8">Find verified properties, create your Renter Passport, and move to the UK with confidence. Free for tenants.</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/listings">
              <Button size="lg" className="bg-emerald-500 hover:bg-emerald-400 text-white px-10 py-6 text-lg font-semibold">
                Browse Properties <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
            </Link>
            <Link href="/contact">
              <Button size="lg" variant="outline" className="border-white/30 text-white hover:bg-white/10 px-10 py-6 text-lg">
                Talk to an Expert
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </PublicLayout>
  );
}
