import { useEffect } from "react";

const BASE_URL = "https://www.elitetenancy.co.uk";
const DEFAULT_TITLE = "Elite Tenancy — Premium UK Lettings Platform";
const DEFAULT_DESC =
  "Elite Tenancy connects high-quality tenants with premium UK rental properties. AI-powered tenant matching, transparent pricing, and dedicated support for landlords and renters.";
const DEFAULT_IMAGE = `${BASE_URL}/og-image.jpg`;

interface SeoOptions {
  title?: string;
  description?: string;
  canonical?: string;
  ogImage?: string;
  /** Set true for auth/dashboard pages that should not be indexed */
  noindex?: boolean;
}

/**
 * Dynamically updates <title>, meta description, canonical link, OG/Twitter
 * tags and robots directive for each page.
 *
 * Called at the top level of every public page component.
 * Resets to defaults on unmount so navigating back to a page
 * without useSeo doesn't leave stale values.
 */
export function useSeo({ title, description, canonical, ogImage, noindex }: SeoOptions = {}) {
  const fullTitle = title ? `${title} | Elite Tenancy` : DEFAULT_TITLE;
  const fullDesc = description ?? DEFAULT_DESC;
  const fullImage = ogImage ?? DEFAULT_IMAGE;

  useEffect(() => {
    // ── Title ──────────────────────────────────────────────────────
    document.title = fullTitle;

    // ── Meta description ───────────────────────────────────────────
    let metaDesc = document.querySelector('meta[name="description"]') as HTMLMetaElement | null;
    if (!metaDesc) {
      metaDesc = document.createElement("meta");
      metaDesc.name = "description";
      document.head.appendChild(metaDesc);
    }
    metaDesc.content = fullDesc;

    // ── Robots (noindex for auth/private pages) ────────────────────
    let metaRobots = document.querySelector('meta[name="robots"]') as HTMLMetaElement | null;
    if (!metaRobots) {
      metaRobots = document.createElement("meta");
      metaRobots.name = "robots";
      document.head.appendChild(metaRobots);
    }
    metaRobots.content = noindex ? "noindex, nofollow" : "index, follow";

    // ── Canonical ─────────────────────────────────────────────────
    // Always set; fall back to current page URL so every page gets a unique
    // canonical even when no explicit override is provided.
    const effectiveCanonical =
      canonical ?? `${BASE_URL}${window.location.pathname.replace(/\/$/, "") || "/"}`;
    let link = document.querySelector('link[rel="canonical"]') as HTMLLinkElement | null;
    if (!link) {
      link = document.createElement("link");
      link.rel = "canonical";
      document.head.appendChild(link);
    }
    link.href = effectiveCanonical;

    // ── Open Graph ─────────────────────────────────────────────────
    const setMeta = (selector: string, value: string) => {
      const el = document.querySelector(selector) as HTMLMetaElement | null;
      if (el) el.content = value;
    };
    setMeta('meta[property="og:title"]', fullTitle);
    setMeta('meta[property="og:description"]', fullDesc);
    setMeta('meta[property="og:url"]', effectiveCanonical);
    setMeta('meta[property="og:image"]', fullImage);

    // ── Twitter Card ───────────────────────────────────────────────
    setMeta('meta[name="twitter:title"]', fullTitle);
    setMeta('meta[name="twitter:description"]', fullDesc);
    setMeta('meta[name="twitter:image"]', fullImage);

    return () => {
      // Reset on unmount to prevent stale tags leaking into the next page
      document.title = DEFAULT_TITLE;
      if (metaDesc) metaDesc.content = DEFAULT_DESC;
      if (metaRobots) metaRobots.content = "index, follow";
    };
  }, [fullTitle, fullDesc, canonical, ogImage, noindex]);
}
