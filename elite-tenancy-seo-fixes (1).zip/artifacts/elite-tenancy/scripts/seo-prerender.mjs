/**
 * seo-prerender.mjs — Post-build static HTML generator
 *
 * Generates per-route index.html files in dist/public so Googlebot receives
 * the correct <title>, meta description, canonical, H1, and structured data
 * immediately — without waiting for JavaScript to execute.
 *
 * Vercel always serves a real static file before applying catch-all rewrites,
 * so dist/public/listings/index.html is served directly for /listings, etc.
 *
 * Run after `vite build`: node scripts/seo-prerender.mjs
 */

import { readFileSync, writeFileSync, mkdirSync } from "fs";
import { join } from "path";
import { fileURLToPath } from "url";
import { dirname } from "path";

const __dirname = dirname(fileURLToPath(import.meta.url));
const DIST = join(__dirname, "..", "dist", "public");
const BASE = "https://www.elitetenancy.co.uk";

const ROUTES = [
  { path: "/listings", title: "Premium UK Properties to Rent 2026 | Elite Tenancy", desc: "Find rooms, flats, and houses to rent across London, Manchester, Birmingham, Leeds, Bristol and 20+ UK cities. Verified landlords, zero tenant fees, AI-powered matching.", h1: "Browse Premium Rental Properties" },
  { path: "/for-landlords", title: "Let Your Property with Elite Tenancy | For Landlords", desc: "List your UK rental property with Elite Tenancy. Completion-only fees, 6-stage tenant screening, 12-day average let time. No upfront costs — ever.", h1: "Let Your Property the Elite Way", schema: { "@context": "https://schema.org", "@type": "Service", "name": "Elite Tenancy Landlord Services", "provider": { "@type": "RealEstateAgent", "name": "Elite Tenancy Ltd" }, "serviceType": "Property Letting Service", "areaServed": { "@type": "Country", "name": "United Kingdom" } } },
  { path: "/for-agents", title: "Elite Tenancy for Letting Agents | Partner With Us", desc: "Letting agents: access our verified tenant pool, streamline referencing, and grow your portfolio. Partner with Elite Tenancy for premium UK lettings.", h1: "Partner With Elite Tenancy" },
  { path: "/pricing", title: "Transparent Lettings Pricing | Elite Tenancy", desc: "Simple, completion-only pricing. Two weeks' rent for tenant introduction or 8% for full management. No hidden fees, no upfront costs.", h1: "Clear, Completion-Only Pricing" },
  { path: "/how-it-works", title: "How Elite Tenancy Works | UK Lettings Made Simple", desc: "Four simple steps: free valuation, professional marketing, tenant matching, and rigorous screening. Let your property in 12 days on average.", h1: "How Elite Tenancy Works" },
  { path: "/find-a-room", title: "Find a Room to Rent in the UK | Elite Tenancy", desc: "Search rooms to rent across the UK. Verified landlords, no tenant fees, and AI-powered matching to find your perfect room fast.", h1: "Find Your Perfect Room" },
  { path: "/list-your-property", title: "List Your Property | Elite Tenancy for Landlords", desc: "List your UK rental property with Elite Tenancy for free. Professional photography, premium marketing, completion-only fees.", h1: "List Your Property" },
  { path: "/renter-passport", title: "Renter Passport — Verified Tenant Profile | Elite Tenancy", desc: "Create your free Renter Passport — a verified profile that lets landlords trust you instantly. Faster viewings, stronger applications.", h1: "Your Renter Passport" },
  { path: "/right-to-rent-check", title: "Right to Rent Check UK 2026 | Free Checker | Elite Tenancy", desc: "Free Right to Rent checker for UK landlords and tenants. Stay compliant with UK immigration rules — check in minutes.", h1: "Right to Rent Check", schema: { "@context": "https://schema.org", "@type": "FAQPage", "mainEntity": [{ "@type": "Question", "name": "What is a Right to Rent check?", "acceptedAnswer": { "@type": "Answer", "text": "A Right to Rent check is a legal requirement for UK landlords to verify that all adult tenants have the right to live in England before the tenancy begins." } }, { "@type": "Question", "name": "Who needs a Right to Rent check?", "acceptedAnswer": { "@type": "Answer", "text": "All private landlords letting residential accommodation in England must conduct Right to Rent checks on all adults aged 18+ who will occupy the property as their main home." } }] } },
  { path: "/spareroom-alternative", title: "Best SpareRoom Alternative 2026 | Elite Tenancy", desc: "Looking for a SpareRoom alternative? Elite Tenancy offers AI-powered matching, verified landlords, and premium listings — free for tenants.", h1: "The Best SpareRoom Alternative in 2026" },
  { path: "/rra-2025-checker", title: "Renters' Rights Act 2025 Compliance Checker | Elite Tenancy", desc: "Check your compliance with the Renters' Rights Act 2025 (in force May 2026). Free compliance checker for UK landlords and letting agents.", h1: "Renters' Rights Act Compliance Checker", schema: { "@context": "https://schema.org", "@type": "FAQPage", "mainEntity": [{ "@type": "Question", "name": "What is the Renters Rights Act 2025?", "acceptedAnswer": { "@type": "Answer", "text": "The Renters Rights Act 2025 came into force in May 2026, abolishing Section 21 no-fault evictions and fixed-term tenancies. All tenancies are now periodic." } }, { "@type": "Question", "name": "Is Section 21 still legal in 2026?", "acceptedAnswer": { "@type": "Answer", "text": "No. Section 21 was abolished by the Renters Rights Act 2025 which took effect on 1 May 2026. Landlords must now use Section 8 grounds to regain possession." } }] } },
  { path: "/verify-landlord", title: "Verify a UK Landlord | Free Landlord Checker | Elite Tenancy", desc: "Check if a landlord is verified and legitimate before you sign. Our free landlord verification tool helps tenants avoid rental scams.", h1: "Verify a UK Landlord" },
  { path: "/valuation", title: "Free Rental Valuation | How Much Can I Rent My Property For?", desc: "Get a free, accurate rental valuation for your UK property. Our local experts provide data-driven rent estimates in 24 hours.", h1: "Free Rental Valuation" },
  { path: "/blog", title: "UK Lettings Blog — Landlord & Tenant Guides 2026 | Elite Tenancy", desc: "Expert lettings guides for UK landlords and tenants. Renters Rights Act, Section 21, HMO licences, average rents, and more.", h1: "The Elite Tenancy Blog" },
  { path: "/contact", title: "Contact Elite Tenancy | UK Lettings Help & Support", desc: "Get in touch with Elite Tenancy. We help landlords, tenants, and agents across the UK.", h1: "Contact Us" },
  // City pages
  { path: "/london", title: "Properties to Rent in London 2026 | Elite Tenancy", desc: "Find premium rentals in London. Mayfair to Hackney — verified landlords, AI-matched, zero tenant fees. Average £2,850/month.", h1: "Properties to Rent in London" },
  { path: "/manchester", title: "Properties to Rent in Manchester 2026 | Elite Tenancy", desc: "Find premium rentals in Manchester. City Centre to Didsbury — verified landlords, AI-matched, zero tenant fees.", h1: "Properties to Rent in Manchester" },
  { path: "/birmingham", title: "Properties to Rent in Birmingham 2026 | Elite Tenancy", desc: "Find premium rentals in Birmingham. Edgbaston to Jewellery Quarter — verified landlords, AI-matched, zero tenant fees.", h1: "Properties to Rent in Birmingham" },
  { path: "/leeds", title: "Properties to Rent in Leeds 2026 | Elite Tenancy", desc: "Find premium rentals in Leeds. City Centre to Roundhay — verified landlords, AI-matched, zero tenant fees.", h1: "Properties to Rent in Leeds" },
  { path: "/bristol", title: "Properties to Rent in Bristol 2026 | Elite Tenancy", desc: "Find premium rentals in Bristol. Clifton to Harbourside — verified landlords, AI-matched, zero tenant fees.", h1: "Properties to Rent in Bristol" },
  { path: "/sheffield", title: "Properties to Rent in Sheffield 2026 | Elite Tenancy", desc: "Find premium rentals in Sheffield. Verified landlords, AI-matched, zero tenant fees.", h1: "Properties to Rent in Sheffield" },
  { path: "/liverpool", title: "Properties to Rent in Liverpool 2026 | Elite Tenancy", desc: "Find premium rentals in Liverpool. Verified landlords, AI-matched, zero tenant fees.", h1: "Properties to Rent in Liverpool" },
  { path: "/edinburgh", title: "Properties to Rent in Edinburgh 2026 | Elite Tenancy", desc: "Find premium rentals in Edinburgh. Verified landlords, AI-matched, zero tenant fees.", h1: "Properties to Rent in Edinburgh" },
  { path: "/cardiff", title: "Properties to Rent in Cardiff 2026 | Elite Tenancy", desc: "Find premium rentals in Cardiff. Verified landlords, AI-matched, zero tenant fees.", h1: "Properties to Rent in Cardiff" },
  { path: "/glasgow", title: "Properties to Rent in Glasgow 2026 | Elite Tenancy", desc: "Find premium rentals in Glasgow. Verified landlords, AI-matched, zero tenant fees.", h1: "Properties to Rent in Glasgow" },
  // Rooms-to-let pages
  { path: "/rooms-to-let/london", title: "Rooms to Let in London 2026 | Elite Tenancy", desc: "Find verified rooms to let in London. No tenant fees, AI-matched. From £800/month across all London boroughs.", h1: "Rooms to Let in London" },
  { path: "/rooms-to-let/manchester", title: "Rooms to Let in Manchester 2026 | Elite Tenancy", desc: "Find verified rooms to let in Manchester. No tenant fees, AI-matched across all Manchester areas.", h1: "Rooms to Let in Manchester" },
  { path: "/rooms-to-let/birmingham", title: "Rooms to Let in Birmingham 2026 | Elite Tenancy", desc: "Find verified rooms to let in Birmingham. No tenant fees, AI-matched across all Birmingham areas.", h1: "Rooms to Let in Birmingham" },
  { path: "/rooms-to-let/leeds", title: "Rooms to Let in Leeds 2026 | Elite Tenancy", desc: "Find verified rooms to let in Leeds. No tenant fees, AI-matched across all Leeds areas.", h1: "Rooms to Let in Leeds" },
  { path: "/rooms-to-let/bristol", title: "Rooms to Let in Bristol 2026 | Elite Tenancy", desc: "Find verified rooms to let in Bristol. No tenant fees, AI-matched across all Bristol areas.", h1: "Rooms to Let in Bristol" },
  // Blog articles
  { path: "/blog/renters-rights-act-2026-landlord-guide", title: "Renters' Rights Act 2026: The Complete Landlord Guide | Elite Tenancy", desc: "Everything UK landlords need to know about the Renters Rights Act 2025, in force May 2026. Section 21 abolished, new eviction grounds, compliance checklist.", h1: "Renters' Rights Act 2026: The Complete Landlord Guide" },
  { path: "/blog/section-21-abolished-2026-landlord-guide", title: "Section 21 Abolished 2026: What Landlords Must Do | Elite Tenancy", desc: "Section 21 no-fault evictions are now illegal in England. Here's what landlords must do instead under the Renters Rights Act 2026.", h1: "Section 21 Abolished 2026: What Landlords Must Do" },
  { path: "/blog/section-21-abolished-what-it-means-for-tenants", title: "Section 21 Abolished — What It Means for UK Tenants in 2026 | Elite Tenancy", desc: "Section 21 is gone. UK tenants now have stronger rights against eviction. What the abolition of no-fault evictions means for you in 2026.", h1: "Section 21 Abolished: What It Means for Tenants" },
  { path: "/blog/hmo-licence-uk-2026-complete-guide", title: "HMO Licence UK 2026: Complete Guide for Landlords | Elite Tenancy", desc: "Do you need an HMO licence? Requirements, costs, penalties, and how to apply. Complete guide for UK landlords in 2026.", h1: "HMO Licence UK 2026: Complete Guide" },
  { path: "/blog/average-rent-uk-2026-city-price-guide", title: "Average Rent UK 2026: City-by-City Price Guide | Elite Tenancy", desc: "How much does it cost to rent in the UK in 2026? Average rents for London, Manchester, Birmingham, Leeds, Bristol and 20+ cities.", h1: "Average Rent UK 2026: City-by-City Price Guide" },
  { path: "/blog/no-dss-illegal-2026-benefits-tenants-landlord-guide", title: "'No DSS' Is Now Illegal in 2026 | Elite Tenancy", desc: "Blanket No DSS bans are now illegal. Here's what landlords must do when housing benefit tenants apply in 2026.", h1: "'No DSS' Is Now Illegal: What Landlords Must Know" },
  { path: "/blog/letting-agent-fees-uk-2026-landlord-guide", title: "Letting Agent Fees UK 2026: What Do Agents Charge? | Elite Tenancy", desc: "How much do UK letting agents charge landlords in 2026? Full breakdown of tenant find, let-only, and full management fees.", h1: "Letting Agent Fees UK 2026: The Full Breakdown" },
  { path: "/blog/can-landlord-refuse-pets-2026-uk", title: "Can a Landlord Refuse Pets in 2026? UK Law Explained | Elite Tenancy", desc: "Landlords can no longer unreasonably refuse tenants with pets under the Renters Rights Act 2026. Here's what you need to know.", h1: "Can a Landlord Refuse Pets in 2026?" },
  { path: "/blog/buy-to-let-2026-worth-it", title: "Is Buy-to-Let Worth It in 2026? Honest Analysis | Elite Tenancy", desc: "Rising mortgage rates and the Renters Rights Act — is buy-to-let still worth it in 2026? Honest analysis with real numbers.", h1: "Is Buy-to-Let Worth It in 2026?" },
  { path: "/blog/average-rent-manchester-2026-area-guide", title: "Average Rent in Manchester 2026: Area-by-Area Guide | Elite Tenancy", desc: "How much does it cost to rent in Manchester in 2026? City Centre, Didsbury, Chorlton, Salford — complete area-by-area rent guide.", h1: "Average Rent in Manchester 2026: Area Guide" },
  { path: "/blog/average-rent-birmingham-2026", title: "Average Rent in Birmingham 2026 | Elite Tenancy", desc: "Average rents in Birmingham 2026. Edgbaston, Jewellery Quarter, Harborne, Digbeth — how much to budget for Birmingham rentals.", h1: "Average Rent in Birmingham 2026" },
];

function esc(str) {
  return str.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

function buildHtml(baseHtml, route) {
  const url = `${BASE}${route.path}`;
  const safeTitle = esc(route.title);
  const safeDesc = esc(route.desc);
  const safeH1 = esc(route.h1);

  const schemaBlock = route.schema
    ? `\n    <script type="application/ld+json">\n    ${JSON.stringify(route.schema, null, 2)}\n    </script>` : "";

  const pathParts = route.path.split("/").filter(Boolean);
  const breadcrumbItems = [{ "@type": "ListItem", "position": 1, "name": "Home", "item": `${BASE}/` }];
  if (pathParts.length === 1) {
    breadcrumbItems.push({ "@type": "ListItem", "position": 2, "name": route.h1, "item": url });
  } else if (pathParts.length >= 2) {
    const parentPath = `${BASE}/${pathParts[0]}`;
    breadcrumbItems.push({ "@type": "ListItem", "position": 2, "name": pathParts[0].replace(/-/g, " ").replace(/\b\w/g, c => c.toUpperCase()), "item": parentPath });
    breadcrumbItems.push({ "@type": "ListItem", "position": 3, "name": route.h1, "item": url });
  }
  const breadcrumbBlock = `\n    <script type="application/ld+json">\n    ${JSON.stringify({ "@context": "https://schema.org", "@type": "BreadcrumbList", "itemListElement": breadcrumbItems }, null, 2)}\n    </script>`;

  return baseHtml
    .replace(/<title>[^<]*<\/title>/, `<title>${safeTitle}</title>`)
    .replace(/(<meta name="description" content=")[^"]*(")/,  `$1${safeDesc}$2`)
    .replace(/(<link rel="canonical" href=")[^"]*(")/,        `$1${url}$2`)
    .replace(/(<meta property="og:title" content=")[^"]*(")/,       `$1${safeTitle}$2`)
    .replace(/(<meta property="og:description" content=")[^"]*(")/,  `$1${safeDesc}$2`)
    .replace(/(<meta property="og:url" content=")[^"]*(")/,          `$1${url}$2`)
    .replace(/(<meta name="twitter:title" content=")[^"]*(")/,       `$1${safeTitle}$2`)
    .replace(/(<meta name="twitter:description" content=")[^"]*(")/,  `$1${safeDesc}$2`)
    .replace(
      /<noscript>[\s\S]*?<\/noscript>/,
      `<noscript>\n      <main>\n        <h1>${safeH1}</h1>\n        <p>${safeDesc}</p>\n        <nav><ul>\n          <li><a href="/listings">Browse Properties</a></li>\n          <li><a href="/for-landlords">For Landlords</a></li>\n          <li><a href="/blog">Blog</a></li>\n          <li><a href="/contact">Contact</a></li>\n        </ul></nav>\n      </main>\n    </noscript>`
    )
    .replace("</head>", `${schemaBlock}${breadcrumbBlock}\n  </head>`);
}

try {
  const baseHtml = readFileSync(join(DIST, "index.html"), "utf8");
  let count = 0;

  for (const route of ROUTES) {
    const html = buildHtml(baseHtml, route);
    const segments = route.path.split("/").filter(Boolean);
    const dir = join(DIST, ...segments);
    mkdirSync(dir, { recursive: true });
    writeFileSync(join(dir, "index.html"), html, "utf8");
    console.log(`✅  ${route.path}`);
    count++;
  }

  console.log(`\n🚀  Done: ${count} pages pre-rendered with correct SEO meta tags.`);
} catch (err) {
  console.error("❌  seo-prerender failed:", err.message);
  process.exit(1);
}
