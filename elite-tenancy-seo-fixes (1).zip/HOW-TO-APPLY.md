# Elite Tenancy — SEO Fixes Package
Generated: 2026-06-07

## What Changed & Why

### 7 files changed / created:

| File | Change | SEO Impact |
|------|--------|-----------|
| `artifacts/elite-tenancy/index.html` | Added default canonical tag, `<noscript>` fallback with nav links, enhanced schema (BreadcrumbList added), `lang="en-GB"` | 🔴 Critical |
| `artifacts/elite-tenancy/vercel.json` | Build command now runs `seo-prerender.mjs` after Vite build | 🔴 Critical |
| `artifacts/elite-tenancy/scripts/seo-prerender.mjs` | NEW — generates 40+ static HTML files at build time with correct title/desc/canonical per page | 🔴 Critical |
| `artifacts/elite-tenancy/src/hooks/use-seo.ts` | Enhanced — now also updates og:url, twitter:image, supports noindex option, resets canonical on unmount | 🟡 Medium |
| `artifacts/elite-tenancy/src/pages/Home.tsx` | Added missing useSeo() call | 🟡 Medium |
| `artifacts/elite-tenancy/src/pages/ForLandlords.tsx` | Added missing useSeo() call | 🟡 Medium |
| `artifacts/elite-tenancy/public/robots.txt` | Added Crawl-delay hint | 🟢 Low |

## How to Apply

1. Copy these files into your GitHub repo (replace the existing files)
2. `scripts/seo-prerender.mjs` is a NEW file — add it at `artifacts/elite-tenancy/scripts/seo-prerender.mjs`
3. Push to GitHub → Vercel auto-deploys in ~60 seconds

## What happens on next Vercel deploy

1. `pnpm build` runs — Vite builds the React SPA as normal
2. `node scripts/seo-prerender.mjs` runs — generates 40+ static HTML files:
   - `dist/public/listings/index.html` (with correct title/desc for /listings)
   - `dist/public/for-landlords/index.html`
   - `dist/public/blog/index.html`
   - `dist/public/london/index.html`
   - `dist/public/rooms-to-let/london/index.html`
   - ... and 35+ more
3. Vercel deploys — serves real static files to Googlebot, React SPA to users

## After deploying

1. Go to https://search.google.com/search-console
2. Submit https://www.elitetenancy.co.uk/sitemap.xml
3. Use "URL Inspection" → Request Indexing for:
   - https://www.elitetenancy.co.uk/
   - https://www.elitetenancy.co.uk/listings
   - https://www.elitetenancy.co.uk/for-landlords
   - https://www.elitetenancy.co.uk/blog
